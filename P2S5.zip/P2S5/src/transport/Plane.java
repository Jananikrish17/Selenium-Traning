package transport;

public class Plane {

	public static void main(String args[])
	{
		Plane oBritishAirways = new Plane();	
	
	}
	
	
}
