package sWDConcepts;

import transport.Car;

public class ExForCar {

	
	public static void main(String args[])
	{
		Car oHuyndai = new Car("Green", 4);		//Initialization 
		
		//oHuyndai.sColor = "Green";
		
		oHuyndai.moveForward();
		
	}

	
}
